import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Play, Pause, RotateCcw, SkipForward, Settings, Eye, BarChart2, Bell, X, Check, Smartphone } from 'lucide-react';

const DEFAULT_FOCUS_MINUTES = 20;
const DEFAULT_BREAK_SECONDS = 20;
const STORAGE_KEY = 'eye_care_settings_v1';
const STATS_KEY = 'eye_care_stats_v1';

const formatTime = (seconds) => {
  const safe = Math.max(0, Number(seconds) || 0);
  const m = Math.floor(safe / 60);
  const s = Math.floor(safe % 60);
  return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
};

const getTodayString = () => new Date().toISOString().split('T')[0];

export default function App() {
  const [mode, setMode] = useState('focus');
  const [isActive, setIsActive] = useState(false);
  const [remainingTime, setRemainingTime] = useState(DEFAULT_FOCUS_MINUTES * 60);
  const [settings, setSettings] = useState({
    focusTime: DEFAULT_FOCUS_MINUTES * 60,
    breakTime: DEFAULT_BREAK_SECONDS,
    notificationsEnabled: false,
    autoResume: true,
  });
  const [stats, setStats] = useState({
    date: getTodayString(),
    completedBreaks: 0,
    totalFocusSeconds: 0
  });
  const [showSettings, setShowSettings] = useState(false);
  const [showStats, setShowStats] = useState(false);
  const expectedEndTimeRef = useRef(null);
  const timerIntervalRef = useRef(null);

  useEffect(() => {
    const savedSettings = localStorage.getItem(STORAGE_KEY);
    if (savedSettings) {
      try {
        const parsed = JSON.parse(savedSettings);
        setSettings(parsed);
        setRemainingTime(parsed.focusTime);
      } catch {}
    }
    const savedStats = localStorage.getItem(STATS_KEY);
    if (savedStats) {
      try {
        const parsed = JSON.parse(savedStats);
        if (parsed.date === getTodayString()) setStats(parsed);
      } catch {}
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(STATS_KEY, JSON.stringify(stats));
  }, [stats]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  }, [settings]);

  const notifyNativeLayer = useCallback((event, payload = {}) => {
    try {
      if (window.AndroidInterface?.onWebEvent) {
        window.AndroidInterface.onWebEvent(event, JSON.stringify(payload));
      }
    } catch (e) {
      console.warn('Native bridge unavailable', e);
    }
  }, []);

  const applyNativeState = useCallback((data) => {
    if (!data) return;
    if (data.mode) setMode(data.mode);
    if (typeof data.active === 'boolean') setIsActive(data.active);
    if (typeof data.remainingTime === 'number') setRemainingTime(Math.max(0, data.remainingTime));
    if (typeof data.targetEndTime === 'number') {
      expectedEndTimeRef.current = data.targetEndTime;
    } else if (data.active === false) {
      expectedEndTimeRef.current = null;
    }
  }, []);

  useEffect(() => {
    window.__applyNativeTimerState = applyNativeState;
    return () => { delete window.__applyNativeTimerState; };
  }, [applyNativeState]);

  useEffect(() => {
    const onNative = (event) => applyNativeState(event.detail);
    window.addEventListener('nativeTimerUpdate', onNative);
    return () => window.removeEventListener('nativeTimerUpdate', onNative);
  }, [applyNativeState]);

  const requestNotificationPermission = async () => {
    if (window.AndroidInterface?.requestNotificationPermission) {
      window.AndroidInterface.requestNotificationPermission();
      setSettings(s => ({ ...s, notificationsEnabled: true }));
      return true;
    }
    if (!('Notification' in window)) return false;
    if (Notification.permission === 'granted') return true;
    const permission = await Notification.requestPermission();
    const granted = permission === 'granted';
    setSettings(s => ({ ...s, notificationsEnabled: granted }));
    return granted;
  };

  const showNotification = useCallback((title, body) => {
    if (!window.AndroidInterface?.onWebEvent &&
        settings.notificationsEnabled && 'Notification' in window && Notification.permission === 'granted') {
      try { new Notification(title, { body, vibrate: [200, 100, 200] }); } catch {}
    }
    notifyNativeLayer('SHOW_NOTIFICATION', { title, body });
  }, [settings.notificationsEnabled, notifyNativeLayer]);

  const handlePhaseComplete = useCallback(() => {
    if (mode === 'focus') {
      setMode('break');
      setRemainingTime(settings.breakTime);
      showNotification('👁️ Eye Break Time', '20 minutes complete. Look approximately 20 feet (6 meters) away for 20 seconds.');
      expectedEndTimeRef.current = Date.now() + settings.breakTime * 1000;
      setStats(s => ({ ...s, totalFocusSeconds: s.totalFocusSeconds + settings.focusTime }));
    } else {
      setMode('focus');
      setRemainingTime(settings.focusTime);
      showNotification('✅ Break Complete', 'Great job! Back to focus mode.');
      setStats(s => ({ ...s, completedBreaks: s.completedBreaks + 1 }));
      if (settings.autoResume) {
        expectedEndTimeRef.current = Date.now() + settings.focusTime * 1000;
      } else {
        setIsActive(false);
        expectedEndTimeRef.current = null;
      }
    }
  }, [mode, settings, showNotification]);

  useEffect(() => {
    if (!isActive) {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      return;
    }
    timerIntervalRef.current = setInterval(() => {
      if (!expectedEndTimeRef.current) return;
      const left = Math.round((expectedEndTimeRef.current - Date.now()) / 1000);
      if (left <= 0) {
        setRemainingTime(0);
        handlePhaseComplete();
      } else setRemainingTime(left);
    }, 200);
    return () => { if (timerIntervalRef.current) clearInterval(timerIntervalRef.current); };
  }, [isActive, handlePhaseComplete]);

  const toggleTimer = () => {
    if (!isActive) {
      expectedEndTimeRef.current = Date.now() + remainingTime * 1000;
      notifyNativeLayer('TIMER_START', { mode, remainingTime, expectedEndTime: expectedEndTimeRef.current, focusTime: settings.focusTime, breakTime: settings.breakTime, autoResume: settings.autoResume });
      setIsActive(true);
    } else {
      expectedEndTimeRef.current = null;
      notifyNativeLayer('TIMER_PAUSE', { mode, remainingTime });
      setIsActive(false);
    }
  };

  const resetTimer = () => {
    setIsActive(false);
    expectedEndTimeRef.current = null;
    const time = mode === 'focus' ? settings.focusTime : settings.breakTime;
    setRemainingTime(time);
    notifyNativeLayer('TIMER_RESET', { mode });
  };

  const skipPhase = () => {
    if (window.AndroidInterface?.onWebEvent) {
      notifyNativeLayer('SKIP_PHASE', { mode });
    } else {
      handlePhaseComplete();
    }
  };

  const totalDuration = mode === 'focus' ? settings.focusTime : settings.breakTime;
  const progressPercent = totalDuration > 0 ? ((totalDuration - remainingTime) / totalDuration) * 100 : 0;
  const themeColor = mode === 'focus' ? 'text-emerald-400' : 'text-blue-400';
  const ringColor = mode === 'focus' ? 'stroke-emerald-400' : 'stroke-blue-400';
  const bgGradient = mode === 'focus' ? 'bg-gradient-to-br from-slate-900 to-slate-800' : 'bg-gradient-to-br from-slate-900 to-blue-950';

  return (
    <div className={`min-h-screen ${bgGradient} text-slate-100 font-sans flex flex-col`}>
      <header className="flex justify-between items-center p-6">
        <div className="flex items-center space-x-2"><Eye className={themeColor} size={28}/><h1 className="text-xl font-bold tracking-tight">Eye Care</h1></div>
        <div className="flex space-x-4">
          <button onClick={() => setShowStats(true)} className="p-2 hover:bg-slate-700/50 rounded-full"><BarChart2 size={24} className="text-slate-300"/></button>
          <button onClick={() => setShowSettings(true)} className="p-2 hover:bg-slate-700/50 rounded-full"><Settings size={24} className="text-slate-300"/></button>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center p-6">
        <div className={`mb-10 px-6 py-2 rounded-full border border-slate-700 bg-slate-800/50 flex items-center space-x-2 ${themeColor}`}>
          {mode === 'focus' ? <Smartphone size={18}/> : <Eye size={18}/>}
          <span className="font-semibold tracking-wide uppercase text-sm">{mode === 'focus' ? 'Focus Session' : '20-20-20 Break'}</span>
        </div>
        <div className="relative w-72 h-72 sm:w-80 sm:h-80 flex items-center justify-center mb-12">
          <svg className="absolute w-full h-full -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="46" fill="none" strokeWidth="3" className="stroke-slate-700/50"/>
            <circle cx="50" cy="50" r="46" fill="none" strokeWidth="4" className={`${ringColor} transition-all duration-300`} strokeDasharray="289.02" strokeDashoffset={289.02 - (289.02 * progressPercent) / 100} strokeLinecap="round"/>
          </svg>
          <div className="text-center z-10 flex flex-col items-center">
            <span className="text-7xl sm:text-8xl font-light tabular-nums tracking-tighter">{formatTime(remainingTime)}</span>
            {mode === 'break' && <span className="text-blue-300 text-sm mt-4 font-medium max-w-[160px]">Look 20 feet away!</span>}
          </div>
        </div>
        <div className="flex items-center space-x-6">
          <button onClick={resetTimer} className="p-4 rounded-full bg-slate-800 text-slate-300 shadow-lg" aria-label="Reset Timer"><RotateCcw size={28}/></button>
          <button onClick={toggleTimer} className={`p-6 rounded-full shadow-xl ${mode === 'focus' ? 'bg-emerald-500 text-slate-900' : 'bg-blue-500 text-slate-900'}`} aria-label={isActive ? 'Pause' : 'Start'}>
            {isActive ? <Pause size={36} fill="currentColor"/> : <Play size={36} fill="currentColor" className="ml-2"/>}
          </button>
          <button onClick={skipPhase} className="p-4 rounded-full bg-slate-800 text-slate-300 shadow-lg" aria-label="Skip Phase"><SkipForward size={28}/></button>
        </div>
      </main>

      {showSettings && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-slate-950/90">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md shadow-2xl p-6 relative">
            <div className="flex justify-between items-center mb-6"><h2 className="text-2xl font-bold">Settings</h2><button onClick={() => setShowSettings(false)} className="p-2 text-slate-400 rounded-full bg-slate-800"><X size={20}/></button></div>
            <div className="space-y-6 overflow-y-auto max-h-[65vh] pr-2">
              <div className="bg-slate-800/80 p-4 rounded-2xl border border-emerald-500/20"><Smartphone className="text-emerald-400 mb-2" size={20}/><p className="text-sm text-slate-300"><span className="text-emerald-400 font-semibold block mb-1">Developer / Test Mode</span>Reduce timers below to test the app without waiting 20 minutes.</p></div>
              <div className="space-y-4">
                <h3 className="text-sm font-semibold text-slate-400 uppercase">Durations</h3>
                <div><div className="flex justify-between text-sm"><label>Focus Time</label><span className="text-emerald-400 font-medium">{Math.floor(settings.focusTime/60)}m {settings.focusTime%60}s</span></div>
                  <input type="range" min="5" max="3600" step="5" value={settings.focusTime} onChange={e=>{const val=parseInt(e.target.value);setSettings(s=>({...s,focusTime:val}));if(mode==='focus'&&!isActive)setRemainingTime(val)}} className="w-full accent-emerald-500 h-2 bg-slate-800 rounded-lg"/>
                </div>
                <div><div className="flex justify-between text-sm"><label>Break Time</label><span className="text-blue-400 font-medium">{settings.breakTime}s</span></div>
                  <input type="range" min="5" max="120" step="1" value={settings.breakTime} onChange={e=>{const val=parseInt(e.target.value);setSettings(s=>({...s,breakTime:val}));if(mode==='break'&&!isActive)setRemainingTime(val)}} className="w-full accent-blue-500 h-2 bg-slate-800 rounded-lg"/>
                </div>
              </div>
              <hr className="border-slate-800"/>
              <label className="flex items-center justify-between p-3 bg-slate-800 rounded-2xl"><div className="flex items-center space-x-3"><Bell size={20}/><div><div className="font-medium">Notifications</div><div className="text-xs text-slate-400">Android alerts</div></div></div>
                <button onClick={requestNotificationPermission} className={`relative w-12 h-7 rounded-full ${settings.notificationsEnabled?'bg-emerald-500':'bg-slate-600'}`}><div className={`absolute top-1 w-5 h-5 bg-white rounded-full ${settings.notificationsEnabled?'left-6':'left-1'}`}/></button>
              </label>
              <label className="flex items-center justify-between p-3 bg-slate-800 rounded-2xl"><div className="flex items-center space-x-3"><RotateCcw size={20}/><div><div className="font-medium">Auto-resume Focus</div><div className="text-xs text-slate-400">Start focus after break</div></div></div>
                <button onClick={()=>setSettings(s=>({...s,autoResume:!s.autoResume}))} className={`relative w-12 h-7 rounded-full ${settings.autoResume?'bg-blue-500':'bg-slate-600'}`}><div className={`absolute top-1 w-5 h-5 bg-white rounded-full ${settings.autoResume?'left-6':'left-1'}`}/></button>
              </label>
              <button onClick={()=>window.AndroidInterface?.openOverlaySettings?.()} className="w-full p-4 rounded-2xl bg-slate-800 text-left">📱 Enable Floating Reminder<br/><span className="text-xs text-slate-400">Allow Eye Care to display over other apps</span></button>
            </div>
          </div>
        </div>
      )}

      {showStats && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-slate-950/90">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md shadow-2xl p-6">
            <div className="flex justify-between items-center mb-6"><h2 className="text-2xl font-bold">Today's Stats</h2><button onClick={()=>setShowStats(false)} className="p-2 text-slate-400 rounded-full bg-slate-800"><X size={20}/></button></div>
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-slate-800 p-4 rounded-2xl text-center"><div className="text-3xl font-bold">{stats.completedBreaks}</div><div className="text-xs text-slate-400 uppercase">Breaks Completed</div></div>
              <div className="bg-slate-800 p-4 rounded-2xl text-center"><div className="text-3xl font-bold">{Math.round(stats.totalFocusSeconds/60)}m</div><div className="text-xs text-slate-400 uppercase">Total Focus Time</div></div>
            </div>
            <p className="text-sm text-slate-400 text-center">Data resets automatically at midnight. Remember to take breaks consistently.</p>
          </div>
        </div>
      )}
    </div>
  );
}

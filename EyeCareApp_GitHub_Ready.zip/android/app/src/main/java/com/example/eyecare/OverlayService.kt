package com.example.eyecare

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.CountDownTimer
import android.provider.Settings
import android.view.*
import android.widget.*
import kotlin.math.max

class OverlayService : Service() {
    private var view: View? = null
    private var timer: CountDownTimer? = null
    private var wm: WindowManager? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "SHOW_BREAK") show()
        return START_NOT_STICKY
    }

    private fun show() {
        if (!canOverlay(this)) return
        remove()
        val v = layoutInflater.inflate(com.example.eyecare.R.layout.layout_floating_overlay,null)
        val countdown = v.findViewById<TextView>(com.example.eyecare.R.id.countdown)
        v.findViewById<Button>(com.example.eyecare.R.id.dismiss).setOnClickListener { remove(); stopSelf() }
        v.findViewById<Button>(com.example.eyecare.R.id.startBreak).setOnClickListener { remove(); stopSelf() }
        val type = if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(300, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        params.y = 80
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm?.addView(v,params)
        view = v
        timer = object: CountDownTimer(20000,1000) {
            override fun onTick(ms: Long) { countdown.text = format(ms/1000) }
            override fun onFinish() { remove(); stopSelf() }
        }.start()
    }

    private fun format(s: Long) = String.format("%02d:%02d", s/60, s%60)
    private fun remove() { timer?.cancel(); timer=null; view?.let { try { wm?.removeView(it) } catch (_: Exception) {} }; view=null }
    override fun onDestroy() { remove(); super.onDestroy() }
    override fun onBind(intent: Intent?) = null

    companion object {
        fun canOverlay(context: Context) = Settings.canDrawOverlays(context)
    }
}

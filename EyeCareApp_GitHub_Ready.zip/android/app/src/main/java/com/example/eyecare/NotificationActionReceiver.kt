package com.example.eyecare

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        when (intent?.action) {
            NotificationHelper.ACTION_START_BREAK -> {
                val p = context.getSharedPreferences("timer_state", Context.MODE_PRIVATE)
                val remaining = p.getLong("remaining",20L)
                val target = System.currentTimeMillis() + remaining * 1000L
                TimerManager.start(context,"break",remaining,target,p.getLong("focus",1200L),p.getLong("break",20L),p.getBoolean("auto",true))
            }
            NotificationHelper.ACTION_DISMISS -> {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                nm.cancel(9001)
            }
        }
    }
}

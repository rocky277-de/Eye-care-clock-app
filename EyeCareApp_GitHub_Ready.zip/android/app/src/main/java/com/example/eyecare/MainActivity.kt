package com.example.eyecare

import android.Manifest
import android.app.AlarmManager
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private val bridge = object {
        @JavascriptInterface fun onWebEvent(event: String, payload: String) {
            runOnUiThread { handle(event,payload) }
        }
        @JavascriptInterface fun requestNotificationPermission() {
            runOnUiThread { requestNotifications() }
        }
        @JavascriptInterface fun openOverlaySettings() {
            runOnUiThread {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.example.eyecare.R.layout.activity_main)
        NotificationHelper.createChannel(this)
        web = WebView(this)
        findViewById<android.view.ViewGroup>(com.example.eyecare.R.id.root).addView(web, android.view.ViewGroup.LayoutParams(-1,-1))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(bridge,"AndroidInterface")
        web.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 33) requestNotifications()
    }

    private fun handle(event:String,payload:String) {
        val j = try { JSONObject(payload) } catch (_:Exception) { JSONObject() }
        when(event) {
            "TIMER_START" -> TimerManager.start(this,j.optString("mode","focus"),j.optLong("remainingTime",1200),j.optLong("expectedEndTime",System.currentTimeMillis()+1200000),j.optLong("focusTime",1200),j.optLong("breakTime",20),j.optBoolean("autoResume",true))
            "TIMER_PAUSE" -> TimerManager.pause(this,j.optString("mode","focus"),j.optLong("remainingTime",0))
            "TIMER_RESET" -> TimerManager.reset(this,j.optString("mode","focus"), if(j.optString("mode")=="break") j.optLong("breakTime",20) else j.optLong("focusTime",1200))
            "SHOW_NOTIFICATION" -> NotificationHelper.show(this,j.optString("title","Eye Break Time"),j.optString("body","Take an eye break."),j.optString("title").contains("Eye Break"))
            "SKIP_PHASE" -> TimerManager.onAlarm(this)
        }
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) {
            val state = TimerManager.state(this).toString()
            web.post { web.evaluateJavascript("window.__applyNativeTimerState && window.__applyNativeTimerState($state);", null) }
        }
    }

    private fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),501)
    }

    override fun onDestroy() { web.removeJavascriptInterface("AndroidInterface"); web.destroy(); super.onDestroy() }
}

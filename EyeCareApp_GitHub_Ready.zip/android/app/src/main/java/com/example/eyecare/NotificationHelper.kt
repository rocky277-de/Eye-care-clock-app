package com.example.eyecare

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

object NotificationHelper {
    const val CHANNEL = "eye_breaks"
    const val ACTION_START_BREAK = "com.example.eyecare.START_BREAK"
    const val ACTION_DISMISS = "com.example.eyecare.DISMISS"
    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL,"Eye breaks",NotificationManager.IMPORTANCE_HIGH).apply {
                description = "20-20-20 eye break reminders"
            })
        }
    }
    fun show(context: Context, title: String, body: String, breakAction: Boolean) {
        createChannel(context)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val dismiss = PendingIntent.getBroadcast(context, 8002, Intent(context, NotificationActionReceiver::class.java).setAction(ACTION_DISMISS), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = NotificationCompat.Builder(context, CHANNEL).setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle(title).setContentText(body).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true)
            .addAction(android.R.drawable.ic_media_pause,"Dismiss",dismiss)
        if (breakAction) {
            val start = PendingIntent.getBroadcast(context, 8001, Intent(context, NotificationActionReceiver::class.java).setAction(ACTION_START_BREAK), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            b.addAction(android.R.drawable.ic_media_play,"Start Break",start)
        }
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(9001,b.build())
    }
}

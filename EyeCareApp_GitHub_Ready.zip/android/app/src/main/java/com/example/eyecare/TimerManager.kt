package com.example.eyecare

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject
import kotlin.math.max

object TimerManager {
    private const val PREF = "timer_state"
    private const val KEY_ACTIVE = "active"
    private const val KEY_MODE = "mode"
    private const val KEY_TARGET = "target"
    private const val KEY_REMAINING = "remaining"
    private const val KEY_FOCUS = "focus"
    private const val KEY_BREAK = "break"
    private const val KEY_AUTO = "auto"

    fun start(context: Context, mode: String, remaining: Long, target: Long, focus: Long, breakSec: Long, auto: Boolean) {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        p.edit().putBoolean(KEY_ACTIVE,true).putString(KEY_MODE,mode)
            .putLong(KEY_TARGET,target).putLong(KEY_REMAINING,remaining)
            .putLong(KEY_FOCUS,focus).putLong(KEY_BREAK,breakSec).putBoolean(KEY_AUTO,auto).apply()
        schedule(context, target)
    }

    fun pause(context: Context, mode: String, remaining: Long) {
        cancel(context)
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_ACTIVE,false).putString(KEY_MODE,mode).putLong(KEY_REMAINING,remaining).apply()
    }

    fun reset(context: Context, mode: String, duration: Long) {
        cancel(context)
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .clear().putBoolean(KEY_ACTIVE,false).putString(KEY_MODE,mode).putLong(KEY_REMAINING,duration).apply()
    }

    fun schedule(context: Context, target: Long) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(context, 7001, Intent(context, TimerReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) return
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, target, pi)
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(context, 7001, Intent(context, TimerReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.cancel(pi)
    }

    fun state(context: Context): JSONObject {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val active = p.getBoolean(KEY_ACTIVE,false)
        val mode = p.getString(KEY_MODE,"focus") ?: "focus"
        val target = p.getLong(KEY_TARGET,0L)
        val remaining = if (active && target > 0) max(0L, (target - System.currentTimeMillis()) / 1000L) else p.getLong(KEY_REMAINING,0L)
        return JSONObject().apply {
            put("active", active)
            put("mode", mode)
            put("targetEndTime", if (active) target else JSONObject.NULL)
            put("remainingTime", remaining)
            put("focusTime", p.getLong(KEY_FOCUS,1200L))
            put("breakTime", p.getLong(KEY_BREAK,20L))
            put("autoResume", p.getBoolean(KEY_AUTO,true))
        }
    }

    fun onAlarm(context: Context) {
        val p = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        if (!p.getBoolean(KEY_ACTIVE,false)) return
        val mode = p.getString(KEY_MODE,"focus") ?: "focus"
        val focus = p.getLong(KEY_FOCUS,1200L)
        val breakSec = p.getLong(KEY_BREAK,20L)
        val auto = p.getBoolean(KEY_AUTO,true)
        val nextMode: String
        val nextDuration: Long
        if (mode == "focus") {
            nextMode = "break"; nextDuration = breakSec
            NotificationHelper.show(context, "👁️ Eye Break Time", "20 minutes complete. Look approximately 6 meters away for 20 seconds.", true)
            if (OverlayService.canOverlay(context)) context.startService(Intent(context, OverlayService::class.java).setAction("SHOW_BREAK"))
        } else {
            nextMode = "focus"; nextDuration = focus
            NotificationHelper.show(context, "✅ Break Complete", "Great job! Back to focus mode.", false)
        }
        if (mode == "break" && !auto) {
            p.edit().putBoolean(KEY_ACTIVE,false).putString(KEY_MODE,nextMode).putLong(KEY_REMAINING,nextDuration).apply()
            return
        }
        val target = System.currentTimeMillis() + nextDuration * 1000L
        p.edit().putBoolean(KEY_ACTIVE,true).putString(KEY_MODE,nextMode).putLong(KEY_TARGET,target).putLong(KEY_REMAINING,nextDuration).apply()
        schedule(context,target)
    }
}

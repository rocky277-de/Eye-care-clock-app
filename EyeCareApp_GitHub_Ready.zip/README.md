# Eye Care Android App

Mobile-first Android wrapper for the existing 20-20-20 React timer.

## GitHub build
Open Actions → Build Android APK → Run workflow. The workflow builds the React app, copies the production files into Android assets, then builds `app-debug.apk`.

## Permissions
Notifications and Display over other apps are separate permissions. Exact alarms are a separate Android capability and may require the user to enable them in system settings on Android versions that enforce it.

## Important
The native layer is responsible for scheduled background timing. The React UI remains the primary interface.
